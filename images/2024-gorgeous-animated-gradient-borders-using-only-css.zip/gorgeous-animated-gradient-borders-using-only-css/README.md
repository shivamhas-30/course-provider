# Gorgeous animated gradient borders using only CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jlengstorf/pen/WNPGMJo](https://codepen.io/jlengstorf/pen/WNPGMJo).

